const pizzas = [
            { id: 1, name: "Margherita", price: 2890, desc: "Paradicsom, mozzarella, bazsalikom", img: "https://images.unsplash.com/photo-1574071318508-1cdbad80ad38?w=500" },
            { id: 2, name: "Diavola", price: 3490, desc: "Csípős szalámi, mozzarella, chilipehely, paprika, gomba", img: "https://images.unsplash.com/photo-1628840042765-356cda07504e?w=500" },
            { id: 3, name: "Quattro Formaggi", price: 3690, desc: "Mozzarella, gorgonzola, pecorino", img: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500" },
            { id: 4, name: "Pármai", price: 3990, desc: "Pármai sonka, rukkola, parmezán", img: "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=500" }
        ];

        // Kosár betöltése mentésből vagy üresen
        let cart = JSON.parse(localStorage.getItem('gusto_cart')) || [];

        function toggleCart() { document.getElementById('cart-sidebar').classList.toggle('active'); }

        function renderMenu() {
            const list = document.getElementById('pizza-list');
            pizzas.forEach(p => {
                list.innerHTML += `
                    <div class="pizza-card">
                        <img src="${p.img}">
                        <div class="pizza-info">
                            <h3>${p.name}</h3>
                            <p>${p.desc}</p>
                            <span class="price">${p.price.toLocaleString()} Ft</span>
                            <button class="btn-add" onclick="addToCart(${p.id})">Kosárba</button>
                        </div>
                    </div>
                `;
            });
        }

        function renderDaily() {
            const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
            const p = pizzas[dayOfYear % pizzas.length];
            document.getElementById('daily-offer-container').innerHTML = `
                <div class="pizza-card" style="max-width: 450px; margin: 0 auto; border: 2px solid #ff4d00;">
                    <img src="${p.img}">
                    <div class="pizza-info" style="text-align: center;">
                        <span style="color: #ff4d00; font-weight: bold;">MAI KÜLÖNLEGESSÉG</span>
                        <h3>${p.name}</h3>
                        <span class="price">${p.price.toLocaleString()} Ft</span>
                        <button class="btn-add" onclick="addToCart(${p.id})">Kérem az ajánlatot!</button>
                    </div>
                </div>
            `;
        }

        function addToCart(id) {
            const pizza = pizzas.find(p => p.id === id);
            // Minden tételnek adunk egy egyedi ID-t a kosáron belül a törléshez
            const cartItem = { ...pizza, cartId: Date.now() + Math.random() };
            cart.push(cartItem);
            saveAndUpdate();
        }

        function removeFromCart(cartId) {
            cart = cart.filter(item => item.cartId !== cartId);
            saveAndUpdate();
        }

        function saveAndUpdate() {
            localStorage.setItem('gusto_cart', JSON.stringify(cart));
            updateCartUI();
        }

        function updateCartUI() {
            const cartItems = document.getElementById('cart-items');
            const cartCount = document.getElementById('cart-count');
            const cartTotal = document.getElementById('cart-total-price');
            cartItems.innerHTML = "";
            let total = 0;
            cart.forEach((item) => {
                total += item.price;
                cartItems.innerHTML += `
                    <div class="cart-item">
                        <div>
                            <div style="font-weight: bold;">${item.name}</div>
                            <div style="font-size: 0.8rem; color: #aaa;">${item.price.toLocaleString()} Ft</div>
                        </div>
                        <i class="fas fa-trash-alt remove-btn" onclick="removeFromCart(${item.cartId})"></i>
                    </div>
                `;
            });

            cartCount.innerText = cart.length;
            cartTotal.innerText = total.toLocaleString() + " Ft";
        }

        window.onload = () => {
            renderMenu();
            renderDaily();
            updateCartUI(); // Betöltéskor a mentett adatok megjelenítése
        };