<?php
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "pizzeria");

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "DB hiba"]);
    exit;
}

$uri = explode("/", trim($_SERVER["REQUEST_URI"], "/"));
$last = end($uri);


if (isset($_GET["Felhasznalonev"])) {

    $Felhasznalonev = $conn->real_escape_string($_GET["Felhasznalonev"]);
    $sql = "SELECT * FROM felhasznalok WHERE Felhasznalonev='$Felhasznalonev'";
    $res = $conn->query($sql);

    if ($res->num_rows > 0) {
        http_response_code(200);
        echo json_encode($res->fetch_all(MYSQLI_ASSOC));
    } else {
        http_response_code(404);
    }

}
else if (is_numeric($last)) {

    $id = (int)$last;
    $sql = "SELECT * FROM felhasznalok WHERE id=$id";
    $res = $conn->query($sql);

    if ($res->num_rows > 0) {
        http_response_code(200);
        echo json_encode($res->fetch_assoc());
    } else {
        http_response_code(404);
    }

}
else {

    $sql = "SELECT * FROM felhasznalok";
    $res = $conn->query($sql);

    if ($res->num_rows > 0) {
        http_response_code(200);
        echo json_encode($res->fetch_all(MYSQLI_ASSOC));
    } else {
        http_response_code(404);
    }

}

$conn->close();
?>