<?php 

$server ="localhost";
$user = "root";
$password = "";
$dbname = "pizzeria";

$con = mysqli_connect($server, $user, $password, $dbname);

if(!$con){
    die("Adatbázis hiba történt!");
}





?>

