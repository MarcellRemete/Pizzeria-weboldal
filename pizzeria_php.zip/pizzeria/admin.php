<?php
session_start();

if(!$_SESSION['felnev']){
    header("Location: login.php" );
    exit;
}
  
if($_SESSION['Jog'] != "Admin" && $_SESSION['Jog'] != "Tulaj"){
    header("Location: login.php" );
    exit;
}

include "dbcon.php";

$sql = mysqli_query($con, "SELECT * FROM felhasznalok");

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Oldal</title>
    <link rel="stylesheet" href="style.css">
    <style>
        h1{
            /* text-align:center; */
            color: orange;
        }

        a{
            text-decoration: none;
            color: yellow;
        }
        a:visited{
            color: orangered;
        }
    </style>
</head>
<body>


    <main>
        <section>
            <div>
                <h1 id="admin_cim">Admin oldal</h1>
                
                <table border= 1>
                    <tr>
                        <th>id</th>
                        <th>Név</th>
                        <th>Jogosultság</th>
                        <th>Státusz</th>
                        <th>Modosít</th>
                    </tr>
                    <?php while($row = mysqli_fetch_assoc($sql)): ?>
                    <tr>
                        <td><?= $row["Id"] ?></td>
                        <td><?= $row["Felhasznalonev"] ?></td>
                        <td><?= $row["Jog"] ?></td>
                        <td><?= $row["Allapot"] ?></td>
                        <td><a href="edit_user.php?id=<?= $row['Id'] ?>">Módosít</a></td>
                    </tr>
                   <?php endwhile?>

                </table>
            </div>
        </section>
    </main>

   
    <?php echo "Helló, " . $_SESSION['felnev'];?>


</body>
</html>