<?php
session_start();

if(!$_SESSION['felnev']){
    header("Location: login.php" );
    exit;
}
  
if($_SESSION['Jog'] != "Admin" && $_SESSION['Jog'] != "Tulaj"){
    header("Location: login.php" );
    exit;
}

include "dbcon.php";
$userID = $_GET['id'];
$sql = mysqli_query($con, "SELECT * FROM felhasznalok WHERE Id = $userID ");
$user = mysqli_fetch_assoc($sql);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    
    <main>
        <section>
            <div>
                <h1>Admin oldal</h1>
                <?php
                    echo "Felh neve: " . $user["Felhasznalonev"] . "<br>";
                    echo "jogosultsági szint: " . $user["Jog"]. "<br>";
                    echo "Státusza: " . $user["Allapot"]. "<br>";
                ?>

            </div>


             <form method="POST">

            Felhasználó név:
            <input type="text" name="name" value="<?= $user['Felhasznalonev'] ?>"> <br>
            Jogosultság: 

            <select name="role">
                <option value="Felhasznalo" <?= $user['Jog'] == 'user'? 'selected' : '' ?> >Felhasználó</option>
                <option value="Admin" <?= $user['Jog'] == 'admin'? 'selected' : '' ?> >Admin</option>
            </select>
            <br>
            Státusz állapot: 
            <select name="allapot">
                <option value="Aktiv" <?= $user['Allapot'] == 'Aktiv'? 'selected' : '' ?> >Aktív</option>
                <option value="Tiltva" <?= $user['Allapot'] == 'Tiltva'? 'selected' : '' ?> >Tiltva</option>
            </select>
            <br><br>

            <button type="submit">Mentés</button>

        </form>
        </section>
    </main>


</body>
</html>

<?php

    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        $newname = $_POST['name'];
        $newrole = $_POST['role'];
        $newstat = $_POST['allapot'];
        $_SESSION["teszt"] = $newstat;
        mysqli_query($con, "
            UPDATE felhasznalok
            SET Felhasznalonev='$newname', Jog='$newrole', Allapot = '$newstat'
            WHERE id=$userID
        ");
        
        header("Location: admin.php");
        exit;
    }
?>