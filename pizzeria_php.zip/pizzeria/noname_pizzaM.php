<?php
session_start();

if(!$_SESSION['felnev']){
    header("Location: login.php" );
    exit;
}

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1987 | Pizzeria</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
<nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <div class="container-fluid">
        <span class="navbar-brand">1987 Pizzeria</span>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto mb-2 mb-md-0">
                <li class="nav-item"><a class="nav-link" href="#home">Kezdőlap</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">Rólunk</a></li>
                <li class="nav-item"><a class="nav-link" href="#daily">Napi Ajánlat</a></li>
                <li class="nav-item"><a class="nav-link" href="#menu">Étlap</a></li>

                <?php
                if($_SESSION["Jog"] == "Admin" || $_SESSION["Jog"] == "Tulaj"){
                    echo '<li class="nav-item"><a class="nav-link" href="admin.php">Admin oldal</a></li>';
                }
                ?>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <span class="text-white">
                    Belépve: <?php echo $_SESSION['felnev']; ?>
                </span>

                <a href="logaut.php" class="btn btn-outline-light btn-sm">Kilépés</a>

                <div class="position-relative text-warning" onclick="toggleCart()" style="cursor:pointer;">
                    <i class="fas fa-shopping-basket"></i>
                    <span id="cart-count" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-light text-dark">0</span>
                </div>
            </div>
        </div>
    </div>
</nav>


    <div id="cart-sidebar" class="cart-sidebar">
        <div class="cart-header">
            <h3>Kosarad</h3>
            <span class="close-cart" onclick="toggleCart()">&times;</span>
        </div>
        <div id="cart-items" class="cart-items"></div>
        <div style="border-top: 1px solid #333; padding-top: 15px;">
            <strong>Összesen: <span id="cart-total-price">0 Ft</span></strong>
        </div>
        <button class="btn-add" style="margin-top: 20px;" onclick="alert('Rendelés elküldve!')">Fizetés</button>
    </div>

    <header id="home" class="hero">
        <h1 style="font-size: 3.5rem;">1987 Pizzeria</h1>
        <p>Ahol a kemence tüze és a szeretet találkozik.</p>
    </header>

    <section id="about" class="about-section">
        <div class="about-text">
            <h2>A mi történetünk</h2>
            <p>Az 1987 Pizzeria nem csupán egy étterem, hanem egy családi örökség. 2015-ben nyitottuk meg kapuinkat azzal a céllal, hogy a valódi, vékony tésztás nápolyi pizzát hozzuk el a környékre.</p>
            <p style="margin-top: 15px;">Minden alapanyagunkat közvetlenül Olaszországból szerezzük be, a tésztánkat pedig 48 órán át kelesztjük a tökéletes textúra érdekében. Nálunk minden vendég családtag!</p>
        </div>
        <div class="about-image">
            <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80" alt="Pizzasütés közben">
        </div>
    </section>

    <!-- Különleges ajánlat -->
    <section id="daily" style="background: #121212;">
        <h2 style="text-align:center; margin-bottom: 30px;">A Mai Nap Ajánlata</h2>
        <div id="daily-offer-container"></div>
    </section>


    <!-- Menu -->
    <section id="menu">
        <h2 style="text-align:center; margin-bottom: 40px;">Kínálatunk</h2>
        <div class="menu-grid" id="pizza-list"></div>
    </section>

    <footer>
        <p>&copy; 2026 1987 Pizzeria - Modern Olasz Konyha</p>
    </footer>


    
    <script>
        const pizzas = [
            { id: 1, name: "Margherita", price: 2890, desc: "Paradicsom, mozzarella, bazsalikom", img: "https://images.unsplash.com/photo-1574071318508-1cdbad80ad38?w=500" },
            { id: 2, name: "Diavola", price: 3490, desc: "Csípős szalámi, mozzarella, chili", img: "https://images.unsplash.com/photo-1628840042765-356cda07504e?w=500" },
            { id: 3, name: "Quattro Formaggi", price: 3690, desc: "Mozzarella, gorgonzola, pecorino", img: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500" },
            { id: 4, name: "Pármai", price: 3990, desc: "Pármai sonka, rukkola, parmezán", img: "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=500" }
        ];

        // Kosár betöltése mentésből vagy üresen
        let cart = JSON.parse(localStorage.getItem('gusto_cart')) || [];

        function toggleCart() { document.getElementById('cart-sidebar').classList.toggle('active'); }

        function renderMenu() {
            const list = document.getElementById('pizza-list');
            pizzas.forEach(p => {
                list.innerHTML += `
                    <div class="pizza-card">
                        <img src="${p.img}">
                        <div class="pizza-info">
                            <h3>${p.name}</h3>
                            <p>${p.desc}</p>
                            <span class="price">${p.price.toLocaleString()} Ft</span>
                            <button class="btn-add" onclick="addToCart(${p.id})">Kosárba</button>
                        </div>
                    </div>
                `;
            });
        }

        function renderDaily() {
            const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
            const p = pizzas[dayOfYear % pizzas.length];
            document.getElementById('daily-offer-container').innerHTML = `
                <div class="pizza-card" style="max-width: 450px; margin: 0 auto; border: 2px solid #ff4d00;">
                    <img src="${p.img}">
                    <div class="pizza-info" style="text-align: center;">
                        <span style="color: #ff4d00; font-weight: bold;">MAI KÜLÖNLEGESSÉG</span>
                        <h3>${p.name}</h3>
                        <span class="price">${p.price.toLocaleString()} Ft</span>
                        <button class="btn-add" onclick="addToCart(${p.id})">Kérem az ajánlatot!</button>
                    </div>
                </div>
            `;
        }

        function addToCart(id) {
            const pizza = pizzas.find(p => p.id === id);
            // Minden tételnek adunk egy egyedi ID-t a kosáron belül a törléshez
            const cartItem = { ...pizza, cartId: Date.now() + Math.random() };
            cart.push(cartItem);
            saveAndUpdate();
        }

        function removeFromCart(cartId) {
            cart = cart.filter(item => item.cartId !== cartId);
            saveAndUpdate();
        }

        function saveAndUpdate() {
            localStorage.setItem('gusto_cart', JSON.stringify(cart));
            updateCartUI();
        }

        function updateCartUI() {
            const cartItems = document.getElementById('cart-items');
            const cartCount = document.getElementById('cart-count');
            const cartTotal = document.getElementById('cart-total-price');
            
            cartItems.innerHTML = "";
            let total = 0;

            cart.forEach((item) => {
                total += item.price;
                cartItems.innerHTML += `
                    <div class="cart-item">
                        <div>
                            <div style="font-weight: bold;">${item.name}</div>
                            <div style="font-size: 0.8rem; color: #aaa;">${item.price.toLocaleString()} Ft</div>
                        </div>
                        <i class="fas fa-trash-alt remove-btn" onclick="removeFromCart(${item.cartId})"></i>
                    </div>
                `;
            });

            cartCount.innerText = cart.length;
            cartTotal.innerText = total.toLocaleString() + " Ft";
        }

        window.onload = () => {
            renderMenu();
            renderDaily();
            updateCartUI(); // Betöltéskor a mentett adatok megjelenítése
        };
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
