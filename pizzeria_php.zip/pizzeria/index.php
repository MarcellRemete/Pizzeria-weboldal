<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kezdő Oldal</title>
    <link rel="stylesheet" href="style.css">
    <style>
        h1{
            text-align:center;
            font-size:105px;
        }

        a{
            text-decoration:none;
            color:orange;

        }

        #index{
            text-align:center;
        }
    </style>
</head>
<body>
    <h1>Index Oldal</h1>
    <div id="index">
        <a href="http://localhost/pizzeria/login.php"> Belépés</a><br>
        <a href="register.php"> Regisztráció</a>
    </div>
    
</body>
</html>




