<?php
session_start();

include "dbcon.php";

$Felhasznalonev = "";
$Jelszo = "";

if($_SERVER['REQUEST_METHOD'] === 'POST'){
   $Felhasznalonev = $_POST['Felhasznalonev'];
   $Jelszo = $_POST['Jelszo'];  
}

if($Felhasznalonev != "" && $Jelszo != ""){

    $sql = "SELECT * FROM felhasznalok WHERE Felhasznalonev = ? LIMIT 1";

    $stmt = $con->prepare($sql);

    $stmt->bind_param('s', $Felhasznalonev); // ? behelyettesítés: s -> string tipusu paraméter, értéke legyen $user_Felhasznalonev
    $stmt->execute(); // futtatja az SQL-t
    $result = $stmt->get_result(); // eredmény mentése $result-ba
    $user = $result->fetch_assoc(); // asszoc tömbbé alakítja és beteszi az $user-ba
    $stmt->close();

    // ha nincs ilyen felhasználó vagy a jelszó nem stimmel
    if (!$user || !password_verify($Jelszo, $user['Jelszo'])) {
        header('Location: noname_pizzaM.php');
        exit;
    }
     if($user["Allapot"] == "Tiltva"){
         header('Location: tiltva.php');
         exit;
    }

    $_SESSION['user_Id'] = $user['Id'];
    $_SESSION['felnev'] = $user['Felhasznalonev'];
    $_SESSION['Allapot'] = $user['Allapot'];
    $_SESSION['Jog'] = $user['Jog'];

    header("Location: noname_pizzaM.php"); 
    exit;

}

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="wIdth=device-wIdth, initial-scale=1.0">
    <title>Belépés</title>
    <link rel="stylesheet" href="style.css">
    <style>
        a{
            color:darkorange;

        }
    </style>
</head>
<body>

<h1>Belépés</h1>

<form method="POST" action="login.php">
    <label>Név: </label>
    <input type="text" name="Felhasznalonev" required>
    <br><br><br>

    <label>Jelszó: </label>
    <input type="password" name="Jelszo" required placeholder="Ide">

    <br><br><br>
    <button type="submit"> Belépés</button>
    <br><br><br>
    <a href="register.php">Itt tudsz regizni!</a>
</form>

</body>
</html>