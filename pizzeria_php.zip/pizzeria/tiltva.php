<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tiltott</title>
    <link rel="stylesheet" href="style.css">
    <style>
        h1{
            margin-top:100px;
            text-align:center;
            font-size:100px;
        }

        #kilep{
            text-align: center;
        }

        a{
            border: 3px solid red;
            text-decoration: none;
            font-size: 50px;
            color: orangered;
            background-color: red;
        }
    </style>
</head>
<body>
    <h1>Ki vagy tiltva!</h1>


    <div id="kilep">
        <a href="logaut.php" class="btn btn-outline-light btn-sm">Kilépés</a>
    </div>
    
</body>
</html>