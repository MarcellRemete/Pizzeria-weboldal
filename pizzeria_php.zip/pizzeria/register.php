<?php
session_start();

include "dbcon.php";

$Felhasznalonev = "";
$Jelszo = "";

if($_SERVER['REQUEST_METHOD'] === 'POST'){
   $Felhasznalonev = $_POST['Felhasznalonev'];
   $Jelszo = $_POST['Jelszo'];  
}

if($Felhasznalonev != "" && $Jelszo != ""){
    // JELSZÓ HASH ELÉSE (EGYSZERŰ)
    $hashedPassword = password_hash($Jelszo, PASSWORD_DEFAULT);
  
        
    // SQL beszúrás
    $sql = "INSERT INTO felhasznalok (Felhasznalonev, Jelszo) VALUES (?, ?)";
    $stmt = $con->prepare($sql);
    

    $stmt->bind_param("ss", $Felhasznalonev, $hashedPassword);
    $stmt->execute();
    $stmt->close();

    header("Location: index.php");
    exit;

}

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Regisztráció</h1>

<form  method="POST" action="register.php">
    <label>Név: </label>
    <input type="text" name="Felhasznalonev" required>
    <br><br><br>

    <label>Jelszó: </label>
    <input type="password" name="Jelszo" required placeholder="Jelszó">

    <br><br><br>
    <button type="submit"> Regisztrálok</button>
</form>

</body>
</html>