<?php

require_once "db_connect.php";

header("Content-Type: application/json; charset=UTF-8");

$sql = "SELECT * FROM Felhasznalok WHERE 1=1";


if (!empty($_GET['Felhasznalonev'])) {
    $Felhasznalonev = $_GET['Felhasznalonev'];
    $sql .= " AND Felhasznalonev = '$Felhasznalonev'";
}

if (!empty($_GET['Jelszo'] )) {
    $Jelszo = $_GET['Jelszo'];
    $sql .= " AND Jelszo = '$Jelszo'";
}


$result = mysqli_query($con, $sql);

$pizzeria = [];

while ($row = mysqli_fetch_assoc($result)) {
    $pizzeria[] = $row;
}


//REST státuszkód 
if (count($pizzeria) > 0) {
    http_response_code(200); //minden rendben
    echo json_encode($pizzeria);
} else {
    http_response_code(404); //nincs találat
    echo json_encode([
        "error" => "Nincs találat a megadott feltételekkel"
    ]);
}